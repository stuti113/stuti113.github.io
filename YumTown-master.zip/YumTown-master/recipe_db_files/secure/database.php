<?php
	$HOST = 'localhost';
	$USERNAME = 'root';
	$PASSWORD = 'temporary';
	$DBNAME = 'recipedb';
?>

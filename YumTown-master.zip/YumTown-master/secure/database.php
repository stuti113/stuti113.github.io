<?php
	$HOST = 'localhost';
	$USERNAME = 'andrew';
	$PASSWORD = 'Mizzou1';
	$DBNAME = 'recipedb';
?>

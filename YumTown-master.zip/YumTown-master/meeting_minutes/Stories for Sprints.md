_Stories for Sprints: First Meeting_

- Complete flow diagram
- Complete architecture diagram
- Complete use case diagram - Stuti
- Research API
- ERD
- Server configuration
- MySQL/Apache installation
- Create login page
- Handling login form data
- Create login database
- Normalize ERD
- Decide UI layout
